package com.navi.dao;

import java.util.List;

import com.navi.model.Forum;

public interface ForumDao {
	public void createNewForum(Forum f);
	public List<Forum> getForumList(String username);
	public void delete(int fid);
	public List<Forum> getForum();

}
