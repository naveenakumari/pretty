package com.navi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.navi.dao.UserDao;
import com.navi.model.User;

public class UserServiceImp implements UserService{
	@Autowired
	private UserDao userdao;
	
	@Transactional
	public void setUserDao(UserDao userdao)
	{
		this.userdao=userdao;
	}

	@Transactional

	public void saveOrUpdate(User user) {
		userdao.saveOrUpdate(user);
		
	}

	@Transactional
	public User getUserById(int userid) {
		return userdao.getUserById(userid);
	}

	@Transactional
	public List<User> list() {
		return userdao.list();

	}

	@Transactional
	public User getUserByname(String username) {
		return userdao.getUserByname(username);

	}
	/*@Transactional
	public boolean  login(String username , String password)
	{
		return userdao.login(username, password);
	}*/
}
