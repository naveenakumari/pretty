package com.navi.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.navi.dao.ForumDaoImp;
import com.navi.model.Forum;

public class ForumServiceImp implements ForumService {
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	ForumDaoImp forumdao;

	public void ForumServiceImpl(){}
	
	public  void ForumServiceImpl(SessionFactory sf){
		this.sessionFactory=sf;
	}

	@Override
	public void createNewForum(Forum f) {
		forumdao.createNewForum(f);
		
	}

	@Override
	public List<Forum> getForumList(String UserName) {
		return forumdao.getForumList(UserName);
		
	}

	@Override
	public void delete(int fid) {
		forumdao.delete(fid);

	}

	@Override
	public List<Forum> getForum() {
		System.out.println("I am in forum service");
		return forumdao.getForum();

	}

}
