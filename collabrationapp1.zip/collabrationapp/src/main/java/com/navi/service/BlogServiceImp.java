package com.navi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.navi.dao.BlogDao;
import com.navi.model.Blog;
@Service
public class BlogServiceImp implements BlogService{
	@Autowired
	BlogDao blogdao;
	@Override
	public void createNewBlog(Blog blog) {
		
		blogdao.createNewBlog(blog);
	}

	@Override
	public List<Blog> getBlogList(String bUserName) {
		return blogdao.getBlogList(bUserName);

	}

	@Override
	public Blog getBlogById(int bid) {
		return new Blog();
	}

	@Override
	public Blog getBlogByName(String bname) {
		return new Blog();
	}

	@Override
	public List<Blog> getBlog() {
		System.out.println("i am in blog serivce");
		return blogdao.getBlog();

	}

}
